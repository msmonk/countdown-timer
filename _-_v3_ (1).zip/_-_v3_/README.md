# 時間到請閉嘴_倒數計時器_v3_新增暫停後的「繼續」功能

A Pen created on CodePen.

Original URL: [https://codepen.io/JY-Huang-the-lessful/pen/pvoQoyP](https://codepen.io/JY-Huang-the-lessful/pen/pvoQoyP).

